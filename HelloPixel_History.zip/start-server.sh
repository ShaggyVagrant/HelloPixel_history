#!/usr/bin/env bash
# Запуск локального сервера для HelloPixel Explorer
# Использование: ./start-server.sh  [порт]

PORT="${1:-8080}"
DIR="$(cd "$(dirname "$0")" && pwd)"

cd "$DIR" || exit 1

echo "=========================================="
echo "  HelloPixel Explorer"
echo "  http://localhost:${PORT}"
echo "  Ctrl+C — остановить"
echo "=========================================="

if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT"
elif command -v python >/dev/null 2>&1; then
  python -m http.server "$PORT"
else
  echo "Ошибка: Python не найден. Установите Python 3."
  exit 1
fi
